using UnityEngine;

public class ObstaclePenalty : MonoBehaviour
{
    [SerializeField] private float penaltyTime = 3f;

    private bool canHit = true;
    [SerializeField] private float hitCooldown = 1f;

    private void OnCollisionEnter(Collision collision)
    {
        if (!canHit) return;

        if (collision.gameObject.CompareTag("Player"))
        {
            GameTimer.Instance.AddPenalty(penaltyTime);
            StartCoroutine(HitCooldown());
        }
    }

    private System.Collections.IEnumerator HitCooldown()
    {
        canHit = false;
        yield return new WaitForSeconds(hitCooldown);
        canHit = true;
    }
}