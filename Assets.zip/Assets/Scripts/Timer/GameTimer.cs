using UnityEngine;
using TMPro;

public class GameTimer : MonoBehaviour
{
    public static GameTimer Instance;

    [Header("UI")]
    [SerializeField] private TMP_Text timerText;

    private float timeElapsed = 0f;
    private bool isRunning = true;

    private void Awake()
    {
        Instance = this;
    }

    private void Update()
    {
        if (!isRunning) return;

        timeElapsed += Time.deltaTime;
        UpdateUI();
    }

    private void UpdateUI()
    {
        timerText.text = timeElapsed.ToString("F2") + "s";
    }

    public void AddPenalty(float seconds)
    {
        timeElapsed += seconds;
        UpdateUI();
    }

    public void StopTimer()
    {
        isRunning = false;
    }

    public float GetTime()
    {
        return timeElapsed;
    }
}
