using UnityEngine;

public class HoleTrigger : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            GameTimer.Instance.StopTimer();

            Debug.Log("Finished! Time: " + GameTimer.Instance.GetTime());
        }
    }
}